/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.planmeca_ble;

import java.util.HashMap;


public class SampleGattAttributes {
    private static HashMap<String, String> attributes = new HashMap();
    // GATT service
    public static String PLANMECA = "2bc282a7-6b39-4ecf-a68d-4f73ceb754b9";
    // GATT characteristics
    public static String LED_MIN = "91ca57bc-0d39-4f72-9527-046fc8f00302";
    public static String LED_MAX = "a6e6ac7f-2eae-4af7-aebf-b82f56e07099";
    public static String LED_GAP_SIZE = "1199cf31-50d9-455e-9df6-0572c411e3d9";
    public static String DISTANCE_SENSOR = "a8c46a36-d45e-46dd-8607-95b8c87a52f9";



    static {
        // Services
        attributes.put("00001800-0000-1000-8000-00805f9b34fb", "Generic Access Service");

        attributes.put("0000180a-0000-1000-8000-00805f9b34fb", "Device Information Service");

        attributes.put("2bc282a7-6b39-4ecf-a68d-4f73ceb754b9", "Planmeca");
        // Characteristics
        attributes.put("00002a00-0000-1000-8000-00805f9b34fb", "Device Name");
        attributes.put("00002a01-0000-1000-8000-00805f9b34fb", "Appearances");

        attributes.put("00002a29-0000-1000-8000-00805f9b34fb", "Manufacturer name");
        attributes.put("00002a24-0000-1000-8000-00805f9b34fb", "Model Number String");
        attributes.put("00002a23-0000-1000-8000-00805f9b34fb", "Serial Number");

        attributes.put("91ca57bc-0d39-4f72-9527-046fc8f00302", "Led Min Value");
        attributes.put("a6e6ac7f-2eae-4af7-aebf-b82f56e07099", "Led Max Value");
        attributes.put("1199cf31-50d9-455e-9df6-0572c411e3d9", "Led Gap Size");
        attributes.put("a8c46a36-d45e-46dd-8607-95b8c87a52f9", "Distance Sensor");
    }

    public static String lookup(String uuid, String defaultName) {
        String name = attributes.get(uuid);
        return name == null ? defaultName : name;
    }
}
